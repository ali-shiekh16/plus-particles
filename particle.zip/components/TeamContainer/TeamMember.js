export const TeamMember = [
  "Adam Raza",
  "Sarah Ali",
  "Mosa",
  "Albert",
  "Nagina",
  "Rosina Ras",
];
